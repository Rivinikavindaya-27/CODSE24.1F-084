package com.cruds.gui;

import com.cruds.db.AdminDAO;
import com.cruds.model.Admin;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


public class LoginFrame extends javax.swing.JFrame {

    public LoginFrame() {
        
        initComponents();
        jPanel1.setOpaque(true);
        panelLogin.setOpaque(true);

        // REMOVE or place BEFORE maximizing:
           setSize(1024, 720); // Optional or can be removed
           setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximize
           setLocationRelativeTo(null); // Center

    
    
    
    
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        panelLogin = new javax.swing.JPanel();
        LabelAdmin = new javax.swing.JLabel();
        LabelPass = new javax.swing.JLabel();
        txtAdminId = new javax.swing.JTextField();
        btnLogin = new javax.swing.JButton();
        txtPassword = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Welcome to SIT Library");
        setBackground(new java.awt.Color(204, 204, 255));
        setSize(new java.awt.Dimension(1024, 720));
        getContentPane().setLayout(new java.awt.GridLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setPreferredSize(new java.awt.Dimension(1024, 720));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon("D:\\CODSE241F-084\\Library-Management-master\\src\\com\\cruds\\icons\\library-3.png.png")); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 320, 840, 540));

        panelLogin.setBackground(new java.awt.Color(0, 153, 153));
        panelLogin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LabelAdmin.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        LabelAdmin.setText("Admin ID:");
        panelLogin.add(LabelAdmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 220, 110, 30));

        LabelPass.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        LabelPass.setText("Password:");
        panelLogin.add(LabelPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 280, 120, 31));

        txtAdminId.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtAdminId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAdminIdActionPerformed(evt);
            }
        });
        panelLogin.add(txtAdminId, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 220, 163, 30));

        btnLogin.setBackground(new java.awt.Color(0, 255, 204));
        btnLogin.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/cruds/icons/arrows_12334931-2.png"))); // NOI18N
        btnLogin.setText("Login");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });
        panelLogin.add(btnLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 370, 90, 35));

        txtPassword.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPasswordActionPerformed(evt);
            }
        });
        panelLogin.add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 280, 163, 31));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Welcome to Read Zone Library");
        panelLogin.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 590, 39));

        jPanel1.add(panelLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 80, 720, 720));
        panelLogin.getAccessibleContext().setAccessibleName("");

        getContentPane().add(jPanel1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPasswordActionPerformed

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        String id = txtAdminId.getText().trim();
        String password = String.valueOf(txtPassword.getPassword()).trim();
        if(id.length() == 0 || password.length() == 0)
        {
            JOptionPane.showMessageDialog(panelLogin, "Please enter Email and password", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        AdminDAO dao = new AdminDAO();
        if(dao.isValidAdmin(new Admin(id, password)))
        {
            loggedIn = true;
            System.out.println("Logged in successfully");
            new MainFrame().setVisible(true);
            this.dispose();
        }
        else
        {
            JOptionPane.showMessageDialog(panelLogin, "Invalid Login!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }//GEN-LAST:event_btnLoginActionPerformed

    private void txtAdminIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAdminIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAdminIdActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                LoginFrame LF = new LoginFrame();
                LF.setVisible(true);
                
            }
        });
    }
    
    public static boolean loggedIn = false;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelAdmin;
    private javax.swing.JLabel LabelPass;
    private javax.swing.JButton btnLogin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel panelLogin;
    private javax.swing.JTextField txtAdminId;
    private javax.swing.JPasswordField txtPassword;
    // End of variables declaration//GEN-END:variables
}
